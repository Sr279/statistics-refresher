# Demo video script (under 5 minutes, main flow only)

| Time | What to show | What to say (own words) |
|---|---|---|
| 0:00-0:30 | README + `notes/Statistics_Refresher_Notes.pdf` first page | "My Week 1 project: statistics notes with worked examples, a notebook that runs them, and tested Python functions." |
| 0:30-1:15 | Notes section 1 + notebook Part 1 (mean / median / outlier example) | "One outlier moved the mean from 17 to 28 but the median only from 16.5 to 18." |
| 1:15-2:00 | Part 2 table (variance by hand) + Chart 2 | "Sample variance divides by n minus 1. Data Science revenue is the most spread out." |
| 2:00-2:45 | Part 3: z-score (Chart 3) and Central Limit Theorem (Chart 4) | "Averages become bell-shaped and narrower as n grows." |
| 2:45-3:45 | Part 4: one-sample t-test by hand + Chart 5, then Programming vs Languages | "t = 1.87 with 8 ratings is not significant; but the rating gap between categories is real (d = 0.91)." |
| 3:45-4:30 | Terminal: `pytest -v` showing 32 passed; notebook Part 5 cross-checks | "Each function has a normal test and a failure test; I also checked against numpy and scipy." |
| 4:30-5:00 | Close | "I learned ... Thank you." |

Practise once. Explain the idea in your own words, do not read the formulas aloud.
