# Short note for the portal (edit in your own words)

**What I built:** Statistics notes (PDF + Markdown) with worked examples on mean/median/mode, variance and standard deviation, distributions (normal, binomial, skewed, Central Limit Theorem) and hypothesis tests (one-sample t, Welch t, chi-square, p-values, errors, effect size). I checked each small example by hand, then applied it to a 5,000-order dataset with a notebook and 6 charts. I wrote the formulas as Python functions and tested them with 32 pytest tests (one normal case and one failure case per function) and 10 cross-checks against numpy and scipy.

**What I learned:** (write 2-3 lines yourself: for example why n - 1 is used, how an outlier changes the mean but not the median, what a p-value really means, why "fail to reject" is not the same as "H0 is true".)

**Files:** `notes/Statistics_Refresher_Notes.pdf`, `notes/STATISTICS_NOTES.md`, `Week1_Statistics_Refresher.ipynb`, `stats_utils.py`, `tests/test_stats_utils.py`, README, demo video link.
