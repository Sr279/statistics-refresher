"""Creates the practice dataset  data/pdf_store_orders.csv  (5,000 orders of an online PDF-book store).
It is SEEDED, so you always get the same file. It is practice data with realistic patterns
(seasons, weekends, discounts, ratings) - it is NOT a download from a real company."""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(7)
N = 5000

# --- when did orders happen? (growth over time + busy months + busier weekends)
days = pd.date_range("2025-01-01", "2026-10-31")
month_factor = {1: 1.0, 2: 0.9, 3: 1.2, 4: 1.3, 5: 0.9, 6: 0.8, 7: 0.85, 8: 0.9, 9: 1.1, 10: 1.4, 11: 1.35, 12: 1.0}
growth = 1 + 0.9 * np.arange(len(days)) / (len(days) - 1)
season = np.array([month_factor[m] for m in days.month])
weekend = np.where(days.dayofweek >= 5, 1.35, 1.0)
weights = growth * season * weekend
order_date = np.sort(rng.choice(days.to_numpy(), size=N, p=weights / weights.sum()))

# --- what was bought?
categories = ["Programming", "Data Science", "Exam Prep", "Business", "Languages"]
category = rng.choice(categories, N, p=[0.30, 0.24, 0.26, 0.12, 0.08])
base_price = {"Programming": 450, "Data Science": 600, "Exam Prep": 180, "Business": 400, "Languages": 160}
price = np.array([base_price[c] for c in category]) * rng.lognormal(0, 0.3, N)
price = np.clip(np.round(price / 10) * 10 - 1, 49, 1499).astype(int)

# --- who bought and how?
cities = ["Hyderabad", "Bengaluru", "Chennai", "Visakhapatnam", "Vijayawada",
          "Tirupati", "Kadapa", "Pune", "Mumbai", "Delhi"]
city = rng.choice(cities, N, p=[0.22, 0.16, 0.11, 0.09, 0.09, 0.08, 0.07, 0.07, 0.06, 0.05])
language = rng.choice(["English", "Telugu", "Hindi"], N, p=[0.80, 0.12, 0.08])
device = rng.choice(["Mobile", "Laptop", "Tablet"], N, p=[0.62, 0.30, 0.08])
payment = rng.choice(["UPI", "Card", "Net Banking", "Wallet"], N, p=[0.55, 0.25, 0.12, 0.08])

# --- discount, quantity (bigger discount -> slightly more copies), revenue
discount = rng.choice([0, 5, 10, 15, 20, 25], N, p=[0.35, 0.15, 0.20, 0.12, 0.10, 0.08])
quantity = 1 + rng.poisson(0.10 + 0.025 * discount)
revenue = np.round(price * (1 - discount / 100) * quantity, 2)

# --- rating (1-5): differs by category; 25% of customers did not rate
mean_rating = {"Programming": 4.4, "Data Science": 4.3, "Exam Prep": 3.9, "Business": 4.1, "Languages": 3.7}
rating = np.clip(np.round(rng.normal([mean_rating[c] for c in category], 0.7)), 1, 5).astype(float)
rating[rng.random(N) < 0.25] = np.nan

df = pd.DataFrame({
    "order_id": [f"ORD-{i:05d}" for i in range(1, N + 1)],
    "order_date": pd.to_datetime(order_date).strftime("%Y-%m-%d"),
    "city": city, "category": category, "language": language, "device": device,
    "payment_method": payment, "price_inr": price, "discount_pct": discount,
    "quantity": quantity, "revenue_inr": revenue, "rating": rating,
})
Path("data").mkdir(exist_ok=True)
df.to_csv("data/pdf_store_orders.csv", index=False)
print("Created data/pdf_store_orders.csv with", len(df), "rows")
