# Practice Questions with Answers

Try each one on paper first, then check the answer. (Check with `stats_utils.py` or the notebook.)

**Q1.** Data: [10, 12, 12, 14, 16, 18, 50]. Find the mean, median and mode. Which is the better "typical value"?
**Answer:** mean = 132/7 = 18.86; median = 14; mode = 12. The outlier 50 inflates the mean, so the **median** is the better typical value.

**Q2.** Data: [2, 4, 4, 4, 5, 5, 7, 9]. Find the sample variance and standard deviation (and the population versions).
**Answer:** mean = 5.0; sum of squares = 32; sample variance = 32/7 = **4.5714**, sample SD = **2.138**; population variance = 32/8 = **4**, population SD = **2**.

**Q3.** Marks have mean 50 and SD 10. What is the z-score of 65, and what share of students scored below 65?
**Answer:** z = (65 − 50)/10 = **1.5**; share below = **0.9332** (93.3%).

**Q4.** A fair coin is tossed 5 times. What is the probability of exactly 3 heads?
**Answer:** C(5,3) × 0.5³ × 0.5² = 10/32 = **0.3125**.

**Q5.** Exam scores are normal with mean 60 and SD 12. What fraction scored above 84?
**Answer:** z = (84 − 60)/12 = 2; P(Z > 2) = 1 − 0.9772 = **0.0228** (about 2.3%).

**Q6.** Eight packets should weigh 50 g: [52, 48, 55, 51, 49, 53, 50, 54]. Test H0: μ = 50 at α = 0.05.
**Answer:** mean = 51.5, s = 2.449, t = **1.732**, df = 7, p = **0.127** → fail to reject H0.

**Q7.** A test gives p = 0.03. What is your decision at α = 0.05 and at α = 0.01?
**Answer:** at α = 0.05, 0.03 < 0.05 → **reject H0**; at α = 0.01, 0.03 > 0.01 → **fail to reject H0**. The decision depends on the α you chose before the test.

**Q8.** A shop tests whether a discount increases sales. What are a Type I and a Type II error?
**Answer:** **Type I:** concluding the discount increases sales when it does not (money wasted on discounts). **Type II:** concluding there is no effect when the discount really does help (a missed opportunity).

**Q9.** Group A: mean 4.4, SD 0.6, n = 100. Group B: mean 3.7, SD 0.8, n = 80. Do the means differ? (Welch t-test)
**Answer:** SE = √(0.6²/100 + 0.8²/80) = √0.0116 = 0.1077; t = 0.7 / 0.1077 = **6.50**, df ≈ 143, p ≈ 1.3e-09 → **reject H0**; the groups differ.

**Q10.** True or false?
a) The mean is not affected by outliers. — **False** (the median is robust, not the mean).
b) p = 0.03 means H0 has a 3% chance of being true. — **False**.
c) A larger sample gives a smaller standard error. — **True** (SE = σ/√n).
d) "Fail to reject H0" means H0 is proven true. — **False**.
e) A z-score of 0 means the value equals the mean. — **True**.
