# Statistics Refresher — Notes with Worked Examples
*Mean / median, variance, distributions and hypothesis tests*

**What I hand in (one sentence):** written notes with worked examples on mean/median, variance, distributions and hypothesis tests, a notebook that runs every example, and tested Python functions.

**How these notes work:** each topic has (1) the idea in plain words, (2) a **small worked example you can check by hand**, and (3) an **application on a 5,000-order dataset** of an online PDF store. Each chart answers one question. All numbers come from `Week1_Statistics_Refresher.ipynb`.

> **About the data:** the dataset is a *practice dataset* created by `make_dataset.py` (seeded), not data from a real company. The conclusions describe this dataset only.

---

## 1. Mean, median and mode

| Measure | Formula / idea | Affected by outliers? |
|---|---|---|
| Mean (x̄) | Σx / n | Yes — strongly |
| Median | middle value of the sorted data (average of the two middle values if n is even) | No |
| Mode | most frequent value | No |

### Worked example 1 — downloads of 7 documents in one day
Data: [12, 15, 15, 18, 20, 22, 95]

- **Mean** = (12 + 15 + 15 + 18 + 20 + 22 + 95) / 7 = 197 / 7 = **28.14**
- **Median:** sorted data is the same list; n = 7 is odd, so the median is the 4th value = **18**
- **Mode:** 15 appears twice, every other value once → **15**

**Effect of the outlier 95:** without it the mean is 102 / 6 = **17.0** and the median is (15 + 18) / 2 = **16.5**. The mean dropped by 11.1, the median by only 1.5.

**Which one to use?** Use the **mean** for fairly symmetric data without extreme values; use the **median** when the data is skewed or has outliers (income, prices, delivery times).

### Application — prices and revenue
| | Mean | Median | Skewness |
|---|---|---|---|
| Price per copy (Rs.) | 398.1 | 379.0 | 0.77 |
| Revenue per order (Rs.) | 469.4 | 397.1 | 1.96 |

Mean > median and positive skewness mean a **long right tail**: a few expensive orders pull the mean up. For "a typical order" the median (Rs. 397) is the better answer.

![Chart 1](../images/01_mean_vs_median.png)
*Chart 1 — Question: why do the mean and median of prices differ? Answer: prices are right-skewed.*

---

## 2. Variance and standard deviation

| Measure | Formula | Meaning |
|---|---|---|
| Sample variance (s²) | Σ(x − x̄)² / (n − 1) | average squared distance from the mean |
| Population variance (σ²) | Σ(x − μ)² / n | same, when you have the whole population |
| Standard deviation | √variance | typical distance from the mean, in the data's own units |
| IQR | Q3 − Q1 | spread of the middle 50% (robust to outliers) |

**Why n − 1?** A sample's own mean sits closer to its values than the true mean does, so dividing by n would *underestimate* the spread. Dividing by n − 1 corrects this.

### Worked example 2 — six scores: [4, 8, 6, 5, 3, 7]
Mean = 33 / 6 = 5.5

| x | x − mean | (x − mean)² |
|---|---|---|
| 4 | -1.5 | 2.25 |
| 8 | +2.5 | 6.25 |
| 6 | +0.5 | 0.25 |
| 5 | -0.5 | 0.25 |
| 3 | -2.5 | 6.25 |
| 7 | +1.5 | 2.25 |
| | | **Sum = 17.5** |

- Population variance = 17.5 / 6 = **2.9167**
- Sample variance = 17.5 / 5 = **3.5**, sample standard deviation = √3.5 = **1.8708**
- Quartiles (linear interpolation): Q1 = 4.25, Q3 = 6.75, IQR = **2.5**
- **Outlier rule:** a value is an outlier if it is above Q3 + 1.5 × IQR or below Q1 − 1.5 × IQR.

### Application — spread of revenue per order by category
| category | mean | median | std dev | IQR |
|---|---|---|---|---|
| Business | 479.3 | 419.1 | 231.1 | 230.4 |
| Data Science | 736.9 | 621.7 | 378.2 | 363.4 |
| Exam Prep | 223.0 | 188.1 | 130.0 | 117.2 |
| Languages | 193.0 | 169.0 | 90.7 | 107.3 |
| Programming | 558.6 | 469.0 | 301.4 | 302.2 |

Data Science orders vary the most (standard deviation Rs. 378); Languages orders vary the least (Rs. 91). Overall, 227 orders (4.5%) are above the outlier fence of Rs. 1159.

![Chart 2](../images/02_spread_by_category.png)
*Chart 2 — Question: which category has the most spread-out revenue? Answer: Data Science (tallest box and longest tail).*

---

## 3. Distributions

### 3.1 The normal distribution
Bell-shaped and symmetric; mean = median = mode. The **empirical rule**: about 68% of values lie within 1 standard deviation of the mean, 95% within 2, 99.7% within 3.

**z-score** = (value − mean) / standard deviation — how many standard deviations a value is from the mean.

### Worked example 3 — exam scores
Scores have mean 70 and standard deviation 8. A student scores 82.

- z = (82 − 70) / 8 = **1.5**
- Share of students below 82 = Φ(1.5) = **0.9332** (about 93%); above 82 = **0.0668** (about 6.7%).

| Within … | Probability |
|---|---|
| ±1 SD | 0.6827 |
| ±2 SD | 0.9545 |
| ±3 SD | 0.9973 |

![Chart 3](../images/03_normal_curve.png)
*Chart 3 — Question: where does z = 1.5 fall on a normal curve? Answer: 93.3% of values are below it.*

### 3.2 The binomial distribution
Counts successes in **n** independent tries, each with probability **p**: P(X = k) = C(n, k) · p^k · (1 − p)^(n − k). Mean = n·p, standard deviation = √(n·p·(1 − p)).

### Worked example 4 — 10 customers, 54% pay by UPI
- P(exactly 6 use UPI) = C(10,6) x 0.54^6 x 0.46^4 = 210 x 0.02479 x 0.04477 = 0.2331
- P(8 or more use UPI) = P(8) + P(9) + P(10) = **0.0889**
- Expected number = 10 × 0.54 = **5.4**, standard deviation = √(10 × 0.54 × 0.46) = **1.58**

### 3.3 Other shapes in the data
- **Right-skewed (long tail to the right):** prices and revenue (skewness 0.77 and 1.96).
- **Discrete:** ratings can only be 1, 2, 3, 4 or 5 (most are 4 or 5, skewness −0.36: a slightly longer left tail).

### 3.4 The Central Limit Theorem (CLT)
If you take many random samples and average each one, the averages form an approximately **normal** distribution — even when the data itself is skewed — with mean μ and **standard error = σ / √n**. Rule of thumb: n ≥ 30 is usually enough.

Simulation on revenue per order (population mean 469.4, SD 336.7, strongly skewed), 2,000 samples each:

| Sample size n | Mean of sample means | SD of sample means | Theory σ/√n |
|---|---|---|---|
| 5 | 472.3 | 153.5 | 150.6 |
| 30 | 471.7 | 61.2 | 61.5 |
| 100 | 469.3 | 33.6 | 33.7 |

The sample means centre on the population mean, and their spread follows σ/√n.

![Chart 4](../images/04_central_limit_theorem.png)
*Chart 4 — Question: do sample averages look normal even when single orders are skewed? Answer: yes, and they get narrower as n grows.*

---

## 4. Hypothesis tests

### 4.1 The 6 steps
1. State **H0** (null hypothesis: no effect / no difference) and **H1** (alternative).
2. Choose the significance level **α** (usually 0.05) *before* looking at the result.
3. Choose the test that fits the question (table in 4.8).
4. Calculate the **test statistic**.
5. Find the **p-value** (or compare with the **critical value**).
6. Decide — **reject H0** if p < α, otherwise **fail to reject H0** — and explain it in plain words.

**p-value:** the probability of getting a result at least this extreme *if H0 were true*. It is **not** the probability that H0 is true.

### 4.2 Worked example 5 — one-sample t-test (by hand)
A new book received 8 ratings: [4, 5, 3, 4, 5, 4, 4, 3]. **H0:** true average rating μ = 3.5. **H1:** μ ≠ 3.5. α = 0.05.

1. n = 8, mean = 32 / 8 = **4.0**
2. Deviations from the mean: 0, +1, −1, 0, +1, 0, 0, −1 → squares sum to 4
3. Sample variance = 4 / 7 = 0.5714; s = **0.7559**
4. Standard error = s / √n = 0.7559 / √8 = **0.2673**
5. **t = (x̄ − μ0) / SE = (4.0 − 3.5) / 0.2673 = 1.8708**, degrees of freedom = n − 1 = **7**
6. Critical value (two-sided, α = 0.05, df = 7) = **± 2.365**; p-value = **0.1036**

**Decision:** |t| = 1.87 < 2.365 and p = 0.104 > 0.05 → **fail to reject H0**. With only 8 ratings there is not enough evidence that the average differs from 3.5. This does *not* prove the average is 3.5.

**95% confidence interval** for the true mean = x̄ ± t_crit × SE = 4.0 ± 2.365 × 0.2673 = **(3.37, 4.63)**. It contains 3.5, which agrees with the test.

![Chart 5](../images/05_t_test_decision.png)
*Chart 5 — Question: why is t = 1.87 not significant with only 8 ratings? Answer: it is inside the non-rejection zone; the red tails start at ± 2.36.*

### 4.3 Worked example 6 — two-sample (Welch) t-test: Programming vs Languages ratings
**H0:** the two true average ratings are equal. **H1:** they differ. α = 0.05. Welch's test does not assume equal variances.

| Group | n | mean | std dev |
|---|---|---|---|
| Programming | 1099 | 4.338 | 0.654 |
| Languages | 325 | 3.738 | 0.691 |

t = (x̄₁ − x̄₂) / √(s₁²/n₁ + s₂²/n₂) = **13.92**, df ≈ 508, p-value ≈ 1.6e-37 → **reject H0**.
**Effect size (Cohen's d)** = difference of means / pooled SD = **0.91** (rule of thumb: 0.2 small, 0.5 medium, 0.8 large) → a large difference, not just a statistically detectable one.

95% confidence intervals for the average rating of each category:

| category | mean rating | 95% margin | n |
|---|---|---|---|
| Programming | 4.338 | ± 0.039 | 1099 |
| Data Science | 4.253 | ± 0.045 | 883 |
| Business | 4.116 | ± 0.067 | 456 |
| Exam Prep | 3.916 | ± 0.044 | 979 |
| Languages | 3.738 | ± 0.075 | 325 |

![Chart 6](../images/06_rating_confidence_intervals.png)
*Chart 6 — Question: are the rating differences real or noise? Answer: Programming and Languages intervals are far apart, so the difference is real.*

### 4.4 Worked example 7 — discounts and quantity
**H0:** average copies per order are the same with a discount of 15% or more and with no discount.
No discount: n = 1775, mean = 1.109. Discount ≥ 15%: n = 1503, mean = 1.568.
Welch t = **21.8**, p ≈ 9e-95 → **reject H0**; Cohen's d = 0.81 (large).
*Careful:* the test shows a difference in this data; it does not prove by itself that the discount *caused* it.

### 4.5 Worked example 8 — chi-square test of independence
**H0:** payment method and device are independent (the payment mix is the same on every device). α = 0.05.

| payment_method | Laptop | Mobile | Tablet |
|---|---|---|---|
| Card | 415 | 762 | 126 |
| Net Banking | 173 | 357 | 58 |
| UPI | 794 | 1694 | 212 |
| Wallet | 123 | 252 | 34 |

- Expected count for a cell = (row total × column total) / grand total. Example: UPI & Mobile = 2700 × 3065 / 5000 = **1655.1**, observed = 1694.
- χ² = Σ (observed − expected)² / expected = **9.112**, df = (rows − 1) × (columns − 1) = **6**, p-value = **0.167**

**Decision:** p = 0.167 > 0.05 → **fail to reject H0**. There is no evidence that customers on different devices choose different payment methods.

### 4.6 Errors, α and power
| | H0 is really true | H0 is really false |
|---|---|---|
| **Reject H0** | **Type I error** (false alarm), probability = α | correct (probability = **power**) |
| **Fail to reject H0** | correct | **Type II error** (missed effect), probability = β |

**Simulation:** 2,000 t-tests where both groups came from the *same* population. 98 of them (4.9%) were "significant" — close to α = 5%. That is what α means: you accept about a 5% false-alarm rate.

### 4.7 Statistical vs practical significance
With 5,000 rows even tiny differences can give very small p-values. Always report the **effect size** (Cohen's d) and a **confidence interval**, and ask whether the difference matters for the business.

### 4.8 Which test for which question?
| Question | Test |
|---|---|
| Is the average different from a given number? | one-sample t-test |
| Do two groups have different averages? | Welch two-sample t-test (+ Cohen's d) |
| Are two categorical variables linked? | chi-square test of independence |
| Do 3 or more groups differ? | ANOVA (not covered here) |

### 4.9 Common mistakes
- "p = 0.03 means a 3% chance that H0 is true." — **wrong** (see 4.1).
- "Fail to reject H0 means H0 is true." — **wrong**; the data may be too little.
- Choosing α or the test *after* seeing the data.
- Using the mean for very skewed data without checking the median.
- Confusing a significant difference with an important difference.

---

## 5. How I checked my work
- **Formulas written from scratch** in `stats_utils.py` (mean, median, mode, variance, standard deviation, percentile, IQR, z-score, normal CDF, binomial, t statistics, Cohen's d).
- **32 pytest tests** (`tests/test_stats_utils.py`): for each function one normal case and one failure case, each test checks one thing and has a clear name.
- **10 cross-checks** against numpy and scipy in the notebook (Part 5); all hand examples match scipy (for example t = 1.8708, p = 0.1036).

## 6. Limitations
- Practice data: patterns in real data will differ.
- The t-tests assume the sample means are roughly normal (true here because of the large samples and the CLT); with only 8 ratings (example 5) the result is shaky.
- Multiple tests on the same data raise the chance of a false alarm; do not test everything and report only the "significant" results.
