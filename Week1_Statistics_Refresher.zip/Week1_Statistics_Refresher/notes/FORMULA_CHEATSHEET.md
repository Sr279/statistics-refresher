# Formula Cheat Sheet

| Topic | Formula |
|---|---|
| Mean | x̄ = Σx / n |
| Median | middle value of sorted data (average of 2 middle values if n is even) |
| Sample variance | s² = Σ(x − x̄)² / (n − 1) |
| Population variance | σ² = Σ(x − μ)² / n |
| Standard deviation | s = √s² |
| IQR / outlier fence | IQR = Q3 − Q1; outlier if x > Q3 + 1.5·IQR or x < Q1 − 1.5·IQR |
| z-score | z = (x − μ) / σ |
| Empirical rule | ±1 SD: 68%, ±2 SD: 95%, ±3 SD: 99.7% |
| Binomial | P(X = k) = C(n, k) · pᵏ · (1 − p)ⁿ⁻ᵏ; mean = np; SD = √(np(1 − p)) |
| Standard error of the mean | SE = σ / √n (or s / √n) |
| One-sample t | t = (x̄ − μ0) / (s / √n), df = n − 1 |
| Welch two-sample t | t = (x̄₁ − x̄₂) / √(s₁²/n₁ + s₂²/n₂) |
| Confidence interval (mean) | x̄ ± t_crit · SE |
| Cohen's d | d = (x̄₁ − x̄₂) / pooled SD (0.2 small, 0.5 medium, 0.8 large) |
| Chi-square | χ² = Σ (O − E)² / E; E = row total × column total / grand total; df = (r − 1)(c − 1) |
| Decision rule | reject H0 if p-value < α (or |statistic| > critical value) |
