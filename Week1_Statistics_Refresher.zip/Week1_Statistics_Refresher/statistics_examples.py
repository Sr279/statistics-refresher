"""Week 1 - Statistics refresher: runs every worked example. Run:  python statistics_examples.py"""
import matplotlib
matplotlib.use("Agg")

import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from scipy import stats as st
from stats_utils import (mean, median, mode, variance, std_dev, percentile, iqr, z_score,
                         normal_cdf, binomial_pmf, t_statistic, welch_t, cohens_d)

pd.set_option("display.width", 120)
for folder in ["data", "images", "notes"]:
    Path(folder).mkdir(exist_ok=True)
if not Path("data/pdf_store_orders.csv").exists():       # create the practice data if it is missing
    exec(open("make_dataset.py").read())
orders = pd.read_csv("data/pdf_store_orders.csv")
rng = np.random.default_rng(2026)                        # fixed seed -> same simulation results every time
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 10})
print("Orders loaded:", len(orders))

downloads = [12, 15, 15, 18, 20, 22, 95]
print("Values        :", downloads)
print("Sum / count   :", sum(downloads), "/", len(downloads))
print("Mean          :", round(mean(downloads), 2))
print("Median        :", median(downloads))
print("Mode          :", mode(downloads))
without_outlier = [x for x in downloads if x != 95]
print("\nRemove the outlier 95:")
print("Mean          :", round(mean(without_outlier), 2))
print("Median        :", median(without_outlier))

price, revenue = orders["price_inr"], orders["revenue_inr"]
print(f"Price   : mean = {price.mean():.1f} | median = {price.median():.1f} | skewness = {price.skew():.2f}")
print(f"Revenue : mean = {revenue.mean():.1f} | median = {revenue.median():.1f} | skewness = {revenue.skew():.2f}")
print("Most common discount (mode):", orders["discount_pct"].mode().tolist())

fig, ax = plt.subplots(figsize=(8, 4))
ax.hist(price, bins=30, color="#2a6fdb", edgecolor="white")
ax.axvline(price.mean(), color="#d9534f", linestyle="--", label=f"Mean Rs. {price.mean():.0f}")
ax.axvline(price.median(), color="#5cb85c", linestyle="--", label=f"Median Rs. {price.median():.0f}")
ax.set_title("Chart 1: Prices are right-skewed, so mean > median")
ax.set_xlabel("Price (Rs.)")
ax.set_ylabel("Number of orders")
ax.legend()
plt.tight_layout()
plt.savefig("images/01_mean_vs_median.png", dpi=120)
plt.close()

scores = [4, 8, 6, 5, 3, 7]
m = mean(scores)
steps = pd.DataFrame({"x": scores,
                      "x - mean": [x - m for x in scores],
                      "(x - mean)^2": [(x - m) ** 2 for x in scores]})
print(steps)
ss = steps["(x - mean)^2"].sum()
print("\nMean =", m, "| sum of squares =", ss)
print("Population variance = ss / n       =", round(ss / len(scores), 4))
print("Sample variance     = ss / (n - 1) =", round(ss / (len(scores) - 1), 4))
print("Sample std dev      = sqrt(var)    =", round(std_dev(scores), 4))
print("Q1 =", percentile(scores, 25), "| Q3 =", percentile(scores, 75), "| IQR =", iqr(scores))

summary = orders.groupby("category")["revenue_inr"].agg(mean="mean", median="median", std="std").round(1)
summary["IQR"] = [round(iqr(orders.loc[orders["category"] == c, "revenue_inr"].tolist()), 1) for c in summary.index]
print(summary)
q1, q3 = percentile(revenue.tolist(), 25), percentile(revenue.tolist(), 75)
fence = q3 + 1.5 * (q3 - q1)
n_outliers = int((revenue > fence).sum())
print(f"\nOutlier fence (Q3 + 1.5 x IQR) = Rs. {fence:.0f}; {n_outliers} orders ({100 * n_outliers / len(orders):.1f}%) are above it")

cats = list(summary.sort_values("std", ascending=False).index)
fig, ax = plt.subplots(figsize=(9, 4))
ax.boxplot([orders.loc[orders["category"] == c, "revenue_inr"] for c in cats], showfliers=True)
ax.set_xticklabels(cats)
ax.set_title("Chart 2: Revenue per order by category (box = middle 50%)")
ax.set_ylabel("Revenue per order (Rs.)")
plt.tight_layout()
plt.savefig("images/02_spread_by_category.png", dpi=120)
plt.close()

mu, sigma, score = 70, 8, 82
z = z_score(score, mu, sigma)
print(f"z = ({score} - {mu}) / {sigma} = {z}")
print(f"Share of students below {score}: {normal_cdf(z):.4f} (percentile rank {100 * normal_cdf(z):.1f})")
print(f"Share above {score}: {1 - normal_cdf(z):.4f}")
for k in (1, 2, 3):
    print(f"Within {k} SD of the mean: {normal_cdf(k) - normal_cdf(-k):.4f}")

x = np.linspace(-4, 4, 400)
y = st.norm.pdf(x)
fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(x, y, color="#1F3A5F")
ax.fill_between(x, y, where=(x <= z), color="#2A9D8F", alpha=0.5, label=f"below z = {z}: {normal_cdf(z):.1%} of values")
for k, share in zip((1, 2, 3), (0.6827, 0.9545, 0.9973)):
    for sign in (-1, 1):
        ax.axvline(sign * k, color="#999999", linestyle=":", linewidth=1)
    ax.text(k, st.norm.pdf(0) * 1.02, f"±{k} SD\n{share:.1%}", ha="center", va="bottom", fontsize=8)
ax.set_ylim(0, st.norm.pdf(0) * 1.25)
ax.set_title("Chart 3: Standard normal distribution")
ax.set_xlabel("z-score")
ax.legend(loc="upper left")
plt.tight_layout()
plt.savefig("images/03_normal_curve.png", dpi=120)
plt.close()

p_upi = round((orders["payment_method"] == "UPI").mean(), 2)
n_customers = 10
p6 = binomial_pmf(6, n_customers, p_upi)
p8_plus = sum(binomial_pmf(k, n_customers, p_upi) for k in range(8, n_customers + 1))
print(f"Share paying by UPI in the data: p = {p_upi}")
print(f"P(exactly 6 of 10 use UPI) = {p6:.4f}")
print(f"P(8 or more of 10 use UPI) = {p8_plus:.4f}")
print(f"Expected number = n x p = {n_customers * p_upi:.1f}, SD = sqrt(n p (1 - p)) = {math.sqrt(n_customers * p_upi * (1 - p_upi)):.2f}")

rating_counts = orders["rating"].value_counts().sort_index()
print("Rating counts (a discrete distribution):")
print(rating_counts)
print("\nSkewness: price =", round(orders["price_inr"].skew(), 2), "| rating =", round(orders["rating"].skew(), 2),
      "(0 = symmetric, positive = long right tail, negative = long left tail)")

vals = revenue.to_numpy()
mu_pop, sd_pop = vals.mean(), vals.std(ddof=1)
clt = {n: rng.choice(vals, size=(2000, n)).mean(axis=1) for n in (5, 30, 100)}
print(f"Population (single orders): mean = {mu_pop:.1f}, SD = {sd_pop:.1f}, skewness = {pd.Series(vals).skew():.2f}")
for n, means in clt.items():
    print(f"n = {n:3d}: mean of sample means = {means.mean():.1f} | SD of sample means = {means.std(ddof=1):6.1f}"
          f" | theory SD/sqrt(n) = {sd_pop / math.sqrt(n):6.1f} | skewness = {pd.Series(means).skew():.2f}")

fig, axes = plt.subplots(1, 4, figsize=(13, 3.5), sharey=False)
axes[0].hist(vals, bins=30, color="#d9534f", edgecolor="white")
axes[0].set_title("Single orders")
for ax, (n, means) in zip(axes[1:], clt.items()):
    ax.hist(means, bins=30, color="#2a6fdb", edgecolor="white")
    ax.set_title(f"Average of {n} orders")
for ax in axes:
    ax.set_xlabel("Revenue (Rs.)")
fig.suptitle("Chart 4: Central Limit Theorem - the more orders averaged, the more bell-shaped and narrow")
plt.tight_layout()
plt.savefig("images/04_central_limit_theorem.png", dpi=120)
plt.close()

ratings_new = [4, 5, 3, 4, 5, 4, 4, 3]
mu0, alpha = 3.5, 0.05
t_obs, df_t = t_statistic(ratings_new, mu0)
p_value = 2 * st.t.sf(abs(t_obs), df_t)
t_crit = st.t.ppf(1 - alpha / 2, df_t)
se = std_dev(ratings_new) / math.sqrt(len(ratings_new))
ci = (mean(ratings_new) - t_crit * se, mean(ratings_new) + t_crit * se)
print(f"n = {len(ratings_new)}, mean = {mean(ratings_new)}, s = {std_dev(ratings_new):.4f}, SE = s / sqrt(n) = {se:.4f}")
print(f"t = ({mean(ratings_new)} - {mu0}) / {se:.4f} = {t_obs:.4f}   (df = {df_t})")
print(f"Critical value (two-sided, alpha = {alpha}) = +/-{t_crit:.3f}")
print(f"p-value = {p_value:.4f}")
print("Decision:", "reject H0" if p_value < alpha else "fail to reject H0 (not enough evidence)")
print(f"95% confidence interval for the true mean: ({ci[0]:.2f}, {ci[1]:.2f})")
check = st.ttest_1samp(ratings_new, mu0)
print("scipy check: t =", round(check.statistic, 4), "| p =", round(check.pvalue, 4))

x = np.linspace(-4.5, 4.5, 500)
y = st.t.pdf(x, df_t)
fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(x, y, color="#1F3A5F")
ax.fill_between(x, y, where=(x >= t_crit), color="#E76F51", alpha=0.6, label="rejection region (2.5% in each tail)")
ax.fill_between(x, y, where=(x <= -t_crit), color="#E76F51", alpha=0.6)
ax.axvline(t_obs, color="#2A9D8F", linestyle="--", linewidth=2, label=f"observed t = {t_obs:.2f}")
ax.set_title(f"Chart 5: t-distribution with {df_t} degrees of freedom")
ax.set_xlabel("t")
ax.legend()
plt.tight_layout()
plt.savefig("images/05_t_test_decision.png", dpi=120)
plt.close()

prog = orders.loc[orders["category"] == "Programming", "rating"].dropna().tolist()
lang = orders.loc[orders["category"] == "Languages", "rating"].dropna().tolist()
t_w, df_w = welch_t(prog, lang)
p_w = 2 * st.t.sf(abs(t_w), df_w)
d_w = cohens_d(prog, lang)
print(f"Programming: n = {len(prog)}, mean = {mean(prog):.3f}, sd = {std_dev(prog):.3f}")
print(f"Languages  : n = {len(lang)}, mean = {mean(lang):.3f}, sd = {std_dev(lang):.3f}")
print(f"Welch t = {t_w:.3f}, df = {df_w:.1f}, p-value = {p_w:.2e}")
print(f"Cohen's d (effect size) = {d_w:.2f}")
sc = st.ttest_ind(prog, lang, equal_var=False)
print("scipy check: t =", round(sc.statistic, 3), "| p =", f"{sc.pvalue:.2e}")
print("Decision:", "reject H0" if p_w < 0.05 else "fail to reject H0")

rows = []
for c_, g in orders.groupby("category")["rating"]:
    g = g.dropna().tolist()
    margin = st.t.ppf(0.975, len(g) - 1) * std_dev(g) / math.sqrt(len(g))
    rows.append((c_, mean(g), margin, len(g)))
ci_table = pd.DataFrame(rows, columns=["category", "mean", "margin", "n"]).sort_values("mean", ascending=False)
print(ci_table.round(3))
fig, ax = plt.subplots(figsize=(8, 4))
ax.errorbar(ci_table["category"], ci_table["mean"], yerr=ci_table["margin"], fmt="o", color="#1F3A5F", capsize=5)
ax.set_ylim(3, 5)
ax.set_ylabel("Average rating (95% confidence interval)")
ax.set_title("Chart 6: Average rating by category (bars that do not overlap suggest a real difference)")
plt.tight_layout()
plt.savefig("images/06_rating_confidence_intervals.png", dpi=120)
plt.close()

q0 = orders.loc[orders["discount_pct"] == 0, "quantity"].tolist()
q15 = orders.loc[orders["discount_pct"] >= 15, "quantity"].tolist()
t_q, df_q = welch_t(q15, q0)
p_q = 2 * st.t.sf(abs(t_q), df_q)
print(f"No discount   : n = {len(q0)}, mean quantity = {mean(q0):.3f}")
print(f"Discount >=15%: n = {len(q15)}, mean quantity = {mean(q15):.3f}")
print(f"Welch t = {t_q:.2f}, df = {df_q:.0f}, p-value = {p_q:.2e}, Cohen's d = {cohens_d(q15, q0):.2f}")
print("Decision:", "reject H0" if p_q < 0.05 else "fail to reject H0")

table = pd.crosstab(orders["payment_method"], orders["device"])
print(table)
row_tot, col_tot, grand = table.sum(axis=1), table.sum(axis=0), table.values.sum()
expected = np.outer(row_tot, col_tot) / grand
chi2_manual = ((table.values - expected) ** 2 / expected).sum()
dof = (table.shape[0] - 1) * (table.shape[1] - 1)
p_chi = st.chi2.sf(chi2_manual, dof)
print(f"\nExample expected count: UPI & Mobile = {row_tot['UPI']} x {col_tot['Mobile']} / {grand} = {row_tot['UPI'] * col_tot['Mobile'] / grand:.1f}"
      f" (observed {table.loc['UPI', 'Mobile']})")
print(f"chi-square = sum((observed - expected)^2 / expected) = {chi2_manual:.3f}, df = {dof}, p-value = {p_chi:.3f}")
print("Decision:", "reject H0" if p_chi < 0.05 else "fail to reject H0 (no evidence of a link)")
c = st.chi2_contingency(table)
print("scipy check: chi2 =", round(c[0], 3), "| p =", round(c[1], 3))

trials, false_positives = 2000, 0
for _ in range(trials):
    a, b = rng.normal(0, 1, 30), rng.normal(0, 1, 30)        # both groups from the SAME population: H0 is true
    if st.ttest_ind(a, b, equal_var=False).pvalue < 0.05:
        false_positives += 1
print(f"{false_positives} of {trials} tests were 'significant' although nothing differed = {100 * false_positives / trials:.1f}% (expected about 5%)")

data = rng.normal(50, 10, 200).tolist()
assert math.isclose(mean(data), np.mean(data))
assert math.isclose(median(data), np.median(data))
assert math.isclose(variance(data), np.var(data, ddof=1))
assert math.isclose(variance(data, sample=False), np.var(data))
assert math.isclose(std_dev(data), np.std(data, ddof=1))
assert math.isclose(percentile(data, 90), np.percentile(data, 90))
assert math.isclose(normal_cdf(1.3), st.norm.cdf(1.3))
assert math.isclose(binomial_pmf(4, 9, 0.3), st.binom.pmf(4, 9, 0.3))
t1, d1 = t_statistic(data, 48)
assert math.isclose(t1, st.ttest_1samp(data, 48).statistic)
t2, d2 = welch_t(data[:100], data[100:])
r2 = st.ttest_ind(data[:100], data[100:], equal_var=False)
assert math.isclose(t2, r2.statistic) and math.isclose(d2, getattr(r2, "df", d2))
print("All 10 cross-checks against numpy/scipy passed")
