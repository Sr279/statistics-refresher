"""Tests: one for a normal case and one for a failure case per function; each test checks ONE thing."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import pytest
from stats_utils import (mean, median, mode, variance, std_dev, percentile, iqr, z_score,
                         normal_cdf, binomial_pmf, t_statistic, welch_t, cohens_d)

DATA = [4, 8, 6, 5, 3, 7]          # worked example in the notes: mean 5.5, sample variance 3.5


# ---------- mean ----------
def test_mean_of_worked_example_is_5_point_5():
    assert mean(DATA) == pytest.approx(5.5)

def test_mean_of_empty_list_raises_valueerror():
    with pytest.raises(ValueError):
        mean([])

def test_mean_with_text_value_raises_typeerror():
    with pytest.raises(TypeError):
        mean([1, 2, "three"])


# ---------- median ----------
def test_median_of_odd_count_is_the_middle_value():
    assert median([12, 15, 15, 18, 20, 22, 95]) == 18

def test_median_of_even_count_is_average_of_two_middle_values():
    assert median([15, 15, 18, 20, 22, 12]) == 16.5

def test_median_of_empty_list_raises_valueerror():
    with pytest.raises(ValueError):
        median([])


# ---------- mode ----------
def test_mode_returns_most_frequent_value():
    assert mode([12, 15, 15, 18, 20]) == [15]

def test_mode_returns_all_values_when_there_is_a_tie():
    assert mode([1, 1, 2, 2, 3]) == [1, 2]

def test_mode_of_empty_list_raises_valueerror():
    with pytest.raises(ValueError):
        mode([])


# ---------- variance / standard deviation ----------
def test_sample_variance_of_worked_example_is_3_point_5():
    assert variance(DATA) == pytest.approx(3.5)

def test_population_variance_of_worked_example_is_17_5_over_6():
    assert variance(DATA, sample=False) == pytest.approx(17.5 / 6)

def test_sample_variance_of_one_value_raises_valueerror():
    with pytest.raises(ValueError):
        variance([5])

def test_std_dev_is_square_root_of_variance():
    assert std_dev(DATA) == pytest.approx(3.5 ** 0.5)

def test_std_dev_of_empty_list_raises_valueerror():
    with pytest.raises(ValueError):
        std_dev([])


# ---------- percentile / IQR ----------
def test_percentile_50_equals_median():
    assert percentile(DATA, 50) == pytest.approx(median(DATA))

def test_percentile_above_100_raises_valueerror():
    with pytest.raises(ValueError):
        percentile(DATA, 101)

def test_iqr_of_worked_example_is_2_point_5():
    assert iqr(DATA) == pytest.approx(2.5)

def test_iqr_of_empty_list_raises_valueerror():
    with pytest.raises(ValueError):
        iqr([])


# ---------- z-score / normal distribution ----------
def test_z_score_of_82_with_mean_70_and_sd_8_is_1_point_5():
    assert z_score(82, 70, 8) == pytest.approx(1.5)

def test_z_score_with_zero_sd_raises_valueerror():
    with pytest.raises(ValueError):
        z_score(82, 70, 0)

def test_normal_cdf_at_zero_is_one_half():
    assert normal_cdf(0) == pytest.approx(0.5)

def test_normal_cdf_within_one_sd_is_about_68_percent():
    assert normal_cdf(1) - normal_cdf(-1) == pytest.approx(0.6827, abs=1e-4)


# ---------- binomial ----------
def test_binomial_three_heads_in_five_fair_tosses_is_0_3125():
    assert binomial_pmf(3, 5, 0.5) == pytest.approx(0.3125)

def test_binomial_with_probability_above_one_raises_valueerror():
    with pytest.raises(ValueError):
        binomial_pmf(3, 5, 1.2)

def test_binomial_with_k_larger_than_n_raises_valueerror():
    with pytest.raises(ValueError):
        binomial_pmf(6, 5, 0.5)


# ---------- t statistics ----------
def test_one_sample_t_of_worked_example_is_about_1_point_87():
    t, df = t_statistic([4, 5, 3, 4, 5, 4, 4, 3], 3.5)
    assert t == pytest.approx(1.8708, abs=1e-3)

def test_one_sample_t_has_n_minus_1_degrees_of_freedom():
    t, df = t_statistic([4, 5, 3, 4, 5, 4, 4, 3], 3.5)
    assert df == 7

def test_one_sample_t_with_identical_values_raises_valueerror():
    with pytest.raises(ValueError):
        t_statistic([4, 4, 4, 4], 3.5)

def test_welch_t_is_positive_when_first_group_has_larger_mean():
    t, df = welch_t([10, 12, 11, 13, 12], [8, 9, 7, 8, 9])
    assert t > 0

def test_welch_t_with_one_value_in_a_group_raises_valueerror():
    with pytest.raises(ValueError):
        welch_t([10], [8, 9, 7])


# ---------- effect size ----------
def test_cohens_d_is_zero_for_equal_means():
    assert cohens_d([1, 2, 3], [3, 2, 1]) == pytest.approx(0)

def test_cohens_d_with_constant_groups_raises_valueerror():
    with pytest.raises(ValueError):
        cohens_d([2, 2, 2], [2, 2, 2])
