"""Statistics refresher - formulas written from scratch (pure Python, no numpy needed).
Every function has a hand-checkable example in notes/STATISTICS_NOTES.md and tests in tests/test_stats_utils.py."""
import math


def _check_numbers(data, minimum=1):
    """Stop early with a clear message if the data is empty or contains non-numbers."""
    if data is None or len(data) < minimum:
        raise ValueError(f"need at least {minimum} value(s), got {0 if data is None else len(data)}")
    for x in data:
        if isinstance(x, bool) or not isinstance(x, (int, float)) or math.isnan(x):
            raise TypeError(f"all values must be numbers, found {x!r}")


def mean(data):
    """Arithmetic mean = sum of values / number of values."""
    _check_numbers(data)
    return sum(data) / len(data)


def median(data):
    """Middle value of the sorted data (average of the two middle values if the count is even)."""
    _check_numbers(data)
    s = sorted(data)
    n, mid = len(s), len(s) // 2
    return s[mid] if n % 2 == 1 else (s[mid - 1] + s[mid]) / 2


def mode(data):
    """Most frequent value(s) as a sorted list (a list because there can be a tie)."""
    _check_numbers(data)
    counts = {}
    for x in data:
        counts[x] = counts.get(x, 0) + 1
    top = max(counts.values())
    return sorted(v for v, c in counts.items() if c == top)


def variance(data, sample=True):
    """Average squared distance from the mean. sample=True divides by n-1, sample=False by n."""
    _check_numbers(data, minimum=2 if sample else 1)
    m = mean(data)
    squared = sum((x - m) ** 2 for x in data)
    return squared / (len(data) - 1 if sample else len(data))


def std_dev(data, sample=True):
    """Standard deviation = square root of the variance (same units as the data)."""
    return math.sqrt(variance(data, sample))


def percentile(data, p):
    """p-th percentile (0-100) with linear interpolation (same method as numpy's default)."""
    _check_numbers(data)
    if not 0 <= p <= 100:
        raise ValueError("p must be between 0 and 100")
    s = sorted(data)
    position = (len(s) - 1) * p / 100
    low, high = math.floor(position), math.ceil(position)
    return s[low] + (s[high] - s[low]) * (position - low)


def iqr(data):
    """Inter-quartile range = Q3 - Q1 (the spread of the middle 50% of the data)."""
    return percentile(data, 75) - percentile(data, 25)


def z_score(value, mu, sigma):
    """How many standard deviations a value is above (+) or below (-) the mean."""
    if sigma <= 0:
        raise ValueError("sigma must be positive")
    return (value - mu) / sigma


def normal_cdf(z):
    """P(Z <= z) for the standard normal distribution."""
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))


def binomial_pmf(k, n, p):
    """P(X = k) successes in n independent tries, each with success probability p."""
    if n < 0 or int(n) != n:
        raise ValueError("n must be a non-negative whole number")
    if not 0 <= p <= 1:
        raise ValueError("p must be between 0 and 1")
    if k < 0 or k > n or int(k) != k:
        raise ValueError("k must be a whole number from 0 to n")
    return math.comb(int(n), int(k)) * p ** k * (1 - p) ** (n - k)


def t_statistic(data, mu0):
    """One-sample t statistic and degrees of freedom: t = (sample mean - mu0) / (s / sqrt(n))."""
    _check_numbers(data, minimum=2)
    s = std_dev(data)
    if s == 0:
        raise ValueError("all values are equal, so the standard deviation is 0")
    t = (mean(data) - mu0) / (s / math.sqrt(len(data)))
    return t, len(data) - 1


def welch_t(group_a, group_b):
    """Two-sample (Welch) t statistic and degrees of freedom; does not assume equal variances."""
    _check_numbers(group_a, minimum=2)
    _check_numbers(group_b, minimum=2)
    va, vb = variance(group_a) / len(group_a), variance(group_b) / len(group_b)
    if va + vb == 0:
        raise ValueError("both groups have zero variance")
    t = (mean(group_a) - mean(group_b)) / math.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(group_a) - 1) + vb ** 2 / (len(group_b) - 1))
    return t, df


def cohens_d(group_a, group_b):
    """Effect size: difference of means in units of the pooled standard deviation."""
    _check_numbers(group_a, minimum=2)
    _check_numbers(group_b, minimum=2)
    na, nb = len(group_a), len(group_b)
    pooled_var = ((na - 1) * variance(group_a) + (nb - 1) * variance(group_b)) / (na + nb - 2)
    if pooled_var == 0:
        raise ValueError("pooled variance is 0")
    return (mean(group_a) - mean(group_b)) / math.sqrt(pooled_var)
