# Week 1 — Statistics Refresher

**Task:** Notes with worked examples on mean/median, variance, distributions and hypothesis tests.

**What I hand in (one sentence):** written notes with worked examples (PDF), a notebook that runs every example, and tested Python functions for the formulas.

> The portal shows this task as "Needs changes". I cannot see the mentor's comments, so this version covers everything in the task title and the testing tips. If the mentor wrote specific comments, read them and fix those points first.

## Start here
1. Read **`notes/Statistics_Refresher_Notes.pdf`** (8 pages: notes + formula cheat sheet + practice questions with answers). The same text is in `notes/*.md`.
2. Run **`Week1_Statistics_Refresher.ipynb`** (outputs are already included, but run it yourself once).
3. Run the tests: `pytest -v` -> 32 passed.

## What the notes cover
| Part | Worked by hand | Applied to the 5,000-order data | Chart (question it answers) |
|---|---|---|---|
| 1. Mean, median, mode | downloads of 7 documents, outlier effect | price and revenue are right-skewed | 1: why do mean and median differ? |
| 2. Variance, SD, IQR | 6 scores, population vs sample (n - 1) | spread of revenue by category, outlier fence | 2: which category varies most? |
| 3. Distributions | z-score 1.5 -> 93.3%; binomial (10 customers, UPI) | skewed and discrete shapes; Central Limit Theorem simulation | 3: where does z = 1.5 fall? 4: do averages look normal? |
| 4. Hypothesis tests | one-sample t-test (8 ratings): t = 1.87, p = 0.10 | Welch t (Programming vs Languages), discounts, chi-square (payment vs device), Type I error simulation | 5: why is t = 1.87 not significant? 6: are rating gaps real? |
| 5-6. Checking | 32 tests + 10 numpy/scipy cross-checks | limitations | - |

## Folder
```
Week1_Statistics_Refresher/
  README.md
  requirements.txt
  Week1_Statistics_Refresher.ipynb   <- all worked examples (outputs included)
  statistics_examples.py             <- the same code as one script
  stats_utils.py                     <- formulas written from scratch (13 functions)
  tests/test_stats_utils.py          <- 32 pytest tests
  make_dataset.py                    <- creates the practice dataset
  data/pdf_store_orders.csv          <- 5,000 orders (practice data)
  images/                            <- 6 charts
  notes/
    Statistics_Refresher_Notes.pdf   <- notes + cheat sheet + practice questions
    STATISTICS_NOTES.md              <- main notes
    FORMULA_CHEATSHEET.md
    PRACTICE_QUESTIONS.md            <- 10 questions with worked answers
  docs/DEMO_SCRIPT.md, docs/SUBMISSION_NOTE.md
```

## Setup (use a virtual environment)
```
python -m venv .venv
# Windows:      .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
pytest -v                      # 32 passed
jupyter notebook               # open Week1_Statistics_Refresher.ipynb, Run All
python statistics_examples.py  # or run everything as a script
```
**Google Colab:** upload the notebook, `stats_utils.py` and `make_dataset.py`, then Runtime -> Run all.

## How the tests follow the portal tips
- **One normal case and one failure case** for every function (for example `mean([])` raises `ValueError`, `variance([5])` raises `ValueError`, `z_score(82, 70, 0)` raises `ValueError`).
- **One check per test** and a **clear name**, such as `test_sample_variance_of_worked_example_is_3_point_5`.

## The dataset (please read)
`pdf_store_orders.csv` is a **practice dataset created by `make_dataset.py`**, not data from a real company. Do not call it "real-world data". The statistics are real calculations on this data; the business conclusions apply to this data only.

## Submission checklist
- [ ] Virtual environment created, `pytest -v` shows 32 passed
- [ ] Notebook runs top to bottom ("All 10 cross-checks ... passed" at the end of Part 5)
- [ ] Read the PDF notes and check a few worked examples by hand
- [ ] Write "What I learned" (notebook, `docs/SUBMISSION_NOTE.md`) in your own words
- [ ] Record the demo video (under 5 minutes, `docs/DEMO_SCRIPT.md`)
- [ ] Upload in My Submissions and check the status changes from "Needs changes"
