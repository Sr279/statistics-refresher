# Week 1 · Project 3 — Testing the PDF Library Code with pytest

**Hand-in (one sentence):** Tested Python functions for the PDF library data (size label, reading time, filtering, averages, cleaning) with pytest tests covering a normal case and a failure case for each function.

Builds on Project 1 (PDF Library in SQL) and Project 2 (Pandas on the PDF Library).

## Files
- `pdf_utils.py` – 5 small functions
- `tests/test_pdf_utils.py` – 12 tests; each checks one thing and has a clear name
- `requirements.txt` – pandas, pytest

## How to run
```
python -m venv .venv
# Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
pytest -v
```
Google Colab: upload both files, run `!pip install pytest` then `!pytest -v`.

## Testing approach
- One normal-case test and one failure-case test (bad input raises an error) per function.
- Each test checks one behaviour; the name says what it checks.

## What I learned
(Write in your own words: what a unit test is, how `pytest.raises` works, one failing test you fixed.)

## Screenshot
(Add a screenshot of `pytest -v` with all tests passed.)
