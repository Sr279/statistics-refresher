"""Small, testable helper functions for the PDF library data (Week 1, Project 3)."""
import pandas as pd


def classify_size(size_kb):
    """Return 'Large' for 1000 KB or more, otherwise 'Small'."""
    if not isinstance(size_kb, (int, float)) or isinstance(size_kb, bool):
        raise TypeError("size_kb must be a number")
    if size_kb < 0:
        raise ValueError("size_kb cannot be negative")
    return "Large" if size_kb >= 1000 else "Small"


def reading_time_minutes(page_count, pages_per_minute=2):
    """Estimate reading time in minutes (rounded up)."""
    if page_count <= 0:
        raise ValueError("page_count must be positive")
    if pages_per_minute <= 0:
        raise ValueError("pages_per_minute must be positive")
    return -(-page_count // pages_per_minute)


def filter_by_category(df, category):
    """Return only the documents of one category."""
    if "category" not in df.columns:
        raise KeyError("DataFrame must have a 'category' column")
    return df[df["category"] == category]


def average_pages_by_category(df):
    """Return average page count for each category."""
    if df.empty:
        raise ValueError("DataFrame is empty")
    return df.groupby("category")["page_count"].mean()


def clean_documents(df):
    """Drop rows with missing page_count and keep only positive page counts."""
    cleaned = df.dropna(subset=["page_count"])
    return cleaned[cleaned["page_count"] > 0]
