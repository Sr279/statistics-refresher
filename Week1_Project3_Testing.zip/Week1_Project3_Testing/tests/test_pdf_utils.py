import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import pandas as pd
import pytest
from pdf_utils import (classify_size, reading_time_minutes, filter_by_category,
                       average_pages_by_category, clean_documents)


@pytest.fixture
def documents():
    return pd.DataFrame({
        "title": ["SQL Basics", "Python Guide", "Pandas Notes", "Kaggle Report"],
        "category": ["Database", "Programming", "Programming", "Analytics"],
        "page_count": [24, 40, 18, 12],
    })


# ---- classify_size ----
def test_classify_size_returns_large_for_1500():
    assert classify_size(1500) == "Large"

def test_classify_size_returns_small_for_400():
    assert classify_size(400) == "Small"

def test_classify_size_rejects_negative_size():
    with pytest.raises(ValueError):
        classify_size(-10)

def test_classify_size_rejects_text_size():
    with pytest.raises(TypeError):
        classify_size("big")


# ---- reading_time_minutes ----
def test_reading_time_for_24_pages_is_12_minutes():
    assert reading_time_minutes(24) == 12

def test_reading_time_rejects_zero_pages():
    with pytest.raises(ValueError):
        reading_time_minutes(0)


# ---- filter_by_category ----
def test_filter_by_category_returns_two_programming_documents(documents):
    assert len(filter_by_category(documents, "Programming")) == 2

def test_filter_by_category_without_column_raises_keyerror():
    with pytest.raises(KeyError):
        filter_by_category(pd.DataFrame({"title": ["A"]}), "Database")


# ---- average_pages_by_category ----
def test_average_pages_for_programming_is_29(documents):
    assert average_pages_by_category(documents)["Programming"] == 29

def test_average_pages_on_empty_dataframe_raises():
    with pytest.raises(ValueError):
        average_pages_by_category(pd.DataFrame(columns=["category", "page_count"]))


# ---- clean_documents ----
def test_clean_documents_removes_missing_page_count():
    df = pd.DataFrame({"page_count": [10, None, 5]})
    assert len(clean_documents(df)) == 2

def test_clean_documents_removes_zero_and_negative_pages():
    df = pd.DataFrame({"page_count": [10, 0, -4]})
    assert list(clean_documents(df)["page_count"]) == [10]
