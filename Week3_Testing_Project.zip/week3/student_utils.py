"""Small, testable helper functions for the student dataset (Week 3)."""
import pandas as pd


def calculate_grade(marks):
    """Return a letter grade for a marks value between 0 and 100."""
    if not isinstance(marks, (int, float)) or isinstance(marks, bool):
        raise TypeError("marks must be a number")
    if marks < 0 or marks > 100:
        raise ValueError("marks must be between 0 and 100")
    if marks >= 85:
        return "A"
    if marks >= 70:
        return "B"
    if marks >= 40:
        return "C"
    return "F"


def is_pass(marks):
    """True if marks are 40 or more."""
    return calculate_grade(marks) != "F"


def filter_by_department(df, department):
    """Return only the students of one department."""
    if "department" not in df.columns:
        raise KeyError("DataFrame must have a 'department' column")
    return df[df["department"] == department]


def average_marks_by_department(df):
    """Return average marks for each department."""
    if df.empty:
        raise ValueError("DataFrame is empty")
    return df.groupby("department")["marks"].mean()


def clean_marks(df):
    """Drop rows with missing marks and keep only values from 0 to 100."""
    cleaned = df.dropna(subset=["marks"])
    return cleaned[(cleaned["marks"] >= 0) & (cleaned["marks"] <= 100)]
