import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import pandas as pd
import pytest
from student_utils import (calculate_grade, is_pass, filter_by_department,
                           average_marks_by_department, clean_marks)


@pytest.fixture
def students():
    return pd.DataFrame({
        "name": ["Anu", "Ravi", "Meena", "Kiran"],
        "department": ["AI&DS", "CSE", "AI&DS", "ECE"],
        "marks": [88, 67, 91, 55],
    })


# ---- calculate_grade ----
def test_calculate_grade_returns_a_for_88():
    assert calculate_grade(88) == "A"

def test_calculate_grade_returns_f_below_40():
    assert calculate_grade(39) == "F"

def test_calculate_grade_rejects_marks_above_100():
    with pytest.raises(ValueError):
        calculate_grade(101)

def test_calculate_grade_rejects_text_marks():
    with pytest.raises(TypeError):
        calculate_grade("eighty")


# ---- is_pass ----
def test_is_pass_true_for_40():
    assert is_pass(40) is True

def test_is_pass_false_for_negative_marks_raises():
    with pytest.raises(ValueError):
        is_pass(-5)


# ---- filter_by_department ----
def test_filter_by_department_returns_two_aids_students(students):
    assert len(filter_by_department(students, "AI&DS")) == 2

def test_filter_by_department_without_column_raises_keyerror():
    with pytest.raises(KeyError):
        filter_by_department(pd.DataFrame({"name": ["Anu"]}), "CSE")


# ---- average_marks_by_department ----
def test_average_marks_for_aids_is_89_5(students):
    assert average_marks_by_department(students)["AI&DS"] == 89.5

def test_average_marks_on_empty_dataframe_raises():
    with pytest.raises(ValueError):
        average_marks_by_department(pd.DataFrame(columns=["department", "marks"]))


# ---- clean_marks ----
def test_clean_marks_removes_missing_values():
    df = pd.DataFrame({"marks": [80, None, 60]})
    assert len(clean_marks(df)) == 2

def test_clean_marks_removes_out_of_range_values():
    df = pd.DataFrame({"marks": [80, 150, -3]})
    assert list(clean_marks(df)["marks"]) == [80]
