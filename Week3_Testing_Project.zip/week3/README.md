# Week 3 — Testing Python/Pandas Code with pytest

**Hand-in (one sentence):** A small set of tested Python functions for student data (grades, filtering, averages, cleaning) with pytest tests covering a normal case and a failure case for each function.

## Files
- `student_utils.py` – 5 small functions (`calculate_grade`, `is_pass`, `filter_by_department`, `average_marks_by_department`, `clean_marks`)
- `tests/test_student_utils.py` – 12 tests; each checks one thing and has a clear name
- `requirements.txt` – pandas, pytest

## How to run
```
python -m venv .venv
# Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
pytest -v
```
In Google Colab: upload both files, run `!pip install pytest` then `!pytest -v`.

## Testing approach
- One test for the normal case and one for the failure case (wrong input raises an error).
- Each test checks one behaviour; the test name says what it checks.

## What I learned
(Write in your own words: what a unit test is, how `pytest.raises` works, one failing test you fixed.)

## Screenshot
(Add a screenshot of `pytest -v` showing all tests passed.)
